import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        try {
            // Przygotowanie pliku sztucznego strefy.csv na potrzeby testu
            prepareDummyCsv();

            // --- TEST KROK 1 & 2 ---
            System.out.println("--- Test kroku 2 (Tabela formatów) ---");
            City pl = new City("Warszawa", "Europe/Warsaw", 1, 21.0);
            DigitalClock dc24 = new DigitalClock(pl, DigitalClock.Format.HOUR_24);
            DigitalClock dc12 = new DigitalClock(pl, DigitalClock.Format.HOUR_12);

            int[][] testCases = {
                    {0, 0, 0}, {0, 1, 0}, {1, 0, 0}, {11, 59, 0},
                    {12, 0, 0}, {13, 0, 0}, {23, 59, 0}
            };

            for (int[] t : testCases) {
                dc24.setTime(t[0], t[1], t[2]);
                dc12.setTime(t[0], t[1], t[2]);
                System.out.printf("24h: %s  ->  12h: %s\n", dc24, dc12);
            }

            // Test wyjątku (Krok 1)
            try {
                dc24.setTime(25, 5, 0);
            } catch (IllegalArgumentException e) {
                System.out.println("\nZłapano oczekiwany wyjątek: " + e.getMessage());
            }

            // --- TEST KROK 3 ---
            System.out.println("\n--- Test kroku 3 (Parsowanie pliku) ---");
            Map<String, City> cityMap = City.parseFile("strefy.csv");
            System.out.println("Wczytano miast: " + cityMap.size());

            // --- TEST KROK 4 & 5 ---
            System.out.println("\n--- Test kroku 4 & 5 (Zmiana miast i LMT) ---");
            City lublin = cityMap.get("Lublin");
            if (lublin != null) {
                DigitalClock clock = new DigitalClock(lublin, DigitalClock.Format.HOUR_24);
                clock.setTime(12, 0, 0);
                System.out.println("Czas strefowy Lublin: " + clock);

                LocalTime lmt = lublin.localMeanTime(LocalTime.of(12, 0, 0));
                System.out.println("Czas miejscowy (LMT) Lublin: " + lmt);

                City londyn = cityMap.get("Londyn");
                if (londyn != null) {
                    clock.setCity(londyn);
                    System.out.println("Po zmianie miasta na Londyn, czas strefowy: " + clock);
                }
            }

            // --- TEST KROK 6 ---
            System.out.println("\n--- Test kroku 6 (Sortowanie worstTimezoneFit) ---");
            List<City> cityList = new ArrayList<>(cityMap.values());
            cityList.sort(City::worstTimezoneFit);

            System.out.println("Miasta od najmniej dopasowanej strefy:");
            for (City c : cityList) {
                System.out.print(c.getName() + ", ");
            }
            System.out.println();

            // --- TEST KROK 7 - 12 ---
            System.out.println("\n--- Test kroku 12 (Generowanie zegarów analogowych SVG) ---");
            City warszawa = cityMap.get("Warszawa");
            AnalogClock analogClock = new AnalogClock(warszawa);
            analogClock.setTime(15, 30, 45); // Ustawienie konkretnej godziny bazowej

            AnalogClock.generateAnalogClocksSvg(cityList, analogClock);
            System.out.println("Zadanie wykonane pomyślnie. Pliki SVG zostały wygenerowane.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Pomocnicza metoda generująca plik strefy.csv do testów
    private static void prepareDummyCsv() throws IOException {
        String data = "Lublin;Europe/Warsaw;1;22,56\n" +
                "Warszawa;Europe/Warsaw;1;21,01\n" +
                "Londyn;Europe/London;0;-0,12\n" +
                "Madryt;Europe/Madrid;1;-3,70\n" +
                "Paryz;Europe/Paris;1;2,35\n" +
                "Kair;Africa/Cairo;2;31,23\n" +
                "Sydney;Australia/Sydney;10;151,20\n" +
                "Osaka;Asia/Tokyo;9;135,50";
        try (FileWriter fw = new FileWriter("strefy.csv")) {
            fw.write(data);
        }
    }
}