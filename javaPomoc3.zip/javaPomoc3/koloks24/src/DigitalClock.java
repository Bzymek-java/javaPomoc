public class DigitalClock extends Clock {

    public enum Format {
        HOUR_24, HOUR_12
    }

    private final Format format;

    public DigitalClock(City city, Format format) {
        super(city);
        this.format = format;
    }

    @Override
    public String toString() {
        if (format == Format.HOUR_24) {
            return super.toString();
        } else {
            int hour = currentTime.getHour();
            String amPm = (hour >= 12) ? "PM" : "AM";

            int hour12 = hour % 12;
            if (hour12 == 0) {
                hour12 = 12;
            }

            return String.format("%d:%02d:%02d %s",
                    hour12,
                    currentTime.getMinute(),
                    currentTime.getSecond(),
                    amPm);
        }
    }
}