import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class City {
    private final String name;
    private final String timezone; // np. "Europe/Warsaw"
    private final int offsetHours;  // Przesunięcie strefowe w godzinach (np. +1)
    private final double longitude; // Długość geograficzna

    public City(String name, String timezone, int offsetHours, double longitude) {
        this.name = name;
        this.timezone = timezone;
        this.offsetHours = offsetHours;
        this.longitude = longitude;
    }

    // Akcesory
    public String getName() { return name; }
    public String getTimezone() { return timezone; }
    public int getOffsetHours() { return offsetHours; }
    public double getLongitude() { return longitude; }

    // Krok 3: Parsowanie linii (Zakładamy format: Nazwa;Strefa;Przesunięcie;Długość)
    private static City parseLine(String line) {
        String[] parts = line.split(";");
        String name = parts[0].trim();
        String timezone = parts[1].trim();
        int offset = Integer.parseInt(parts[2].trim());
        double longitude = Double.parseDouble(parts[3].trim().replace(",", "."));
        return new City(name, timezone, offset, longitude);
    }

    public static Map<String, City> parseFile(String filePath) throws IOException {
        Map<String, City> cities = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // Jeśli plik ma nagłówek, odkomentuj poniższą linię:
            // br.readLine(); 
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                City city = parseLine(line);
                cities.put(city.getName(), city);
            }
        }
        return cities;
    }

    // Krok 5: Obliczanie Local Mean Time (LMT)
    public LocalTime localMeanTime(LocalTime zoneTime) {
        // Przesunięcie geograficzne: 180 stopni = 12 godzin (720 minut)
        // Stąd: 1 stopień = 4 minuty = 240 sekund
        double geoOffsetInSeconds = this.longitude * 240.0;
        double zoneOffsetInSeconds = this.offsetHours * 3600.0;

        // Różnica między czasem geograficznym a strefowym
        double diffSeconds = geoOffsetInSeconds - zoneOffsetInSeconds;

        long secondsToAdd = Math.round(diffSeconds);
        return zoneTime.plusSeconds(secondsToAdd);
    }

    // Krok 6: Komparator - im większa niezgodność strefy z geografią, tym wyżej na liście
    public static int worstTimezoneFit(City c1, City c2) {
        double diff1 = Math.abs((c1.getLongitude() * 240.0) - (c1.getOffsetHours() * 3600.0));
        double diff2 = Math.abs((c2.getLongitude() * 240.0) - (c2.getOffsetHours() * 3600.0));
        return Double.compare(diff2, diff1); // Sortowanie malejąco po błędzie
    }
}