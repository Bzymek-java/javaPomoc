import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public abstract class Clock {
    protected LocalTime currentTime;
    protected City city;

    // Konstruktor wymagany przez Krok 4
    public Clock(City city) {
        this.city = city;
        setCurrentTime();
    }

    public void setCurrentTime() {
        // Pobieramy czas systemowy dla strefy czasowej przypisanej do miasta
        this.currentTime = LocalTime.now(ZoneId.of(city.getTimezone()));
        onTimeChanged();
    }

    public void setTime(int hour, int minute, int second) {
        if (hour < 0 || hour > 23) {
            throw new IllegalArgumentException("Godzina '" + hour + "' poza zakresem [0-23].");
        }
        if (minute < 0 || minute > 59) {
            throw new IllegalArgumentException("Minuta '" + minute + "' poza zakresem [0-59].");
        }
        if (second < 0 || second > 59) {
            throw new IllegalArgumentException("Sekunda '" + second + "' poza zakresem [0-59].");
        }
        this.currentTime = LocalTime.of(hour, minute, second);
        onTimeChanged();
    }

    public void setCity(City newCity) {
        if (this.city != null && newCity != null) {
            // Obliczamy różnicę przesunięć między starą a nową strefą czasową
            int oldOffset = this.city.getOffsetHours();
            int newOffset = newCity.getOffsetHours();
            int diff = newOffset - oldOffset;
            this.currentTime = this.currentTime.plusHours(diff);
        }
        this.city = newCity;
        onTimeChanged();
    }

    // Metoda pomocnicza dla Kroku 11 (aktualizacja wskazówek bez nadpisywania metod)
    protected void onTimeChanged() {
        // Domyślnie pusta, zostanie nadpisana w AnalogClock
    }

    @Override
    public String toString() {
        return currentTime.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }
}