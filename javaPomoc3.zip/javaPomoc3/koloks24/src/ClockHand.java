import java.time.LocalTime;

// Krok 8: Klasa abstrakcyjna
public abstract class ClockHand {
    protected double angle;
    public abstract void setTime(LocalTime time);
    public abstract String toSvg();
}

// Krok 9: Wskazówka sekundowa (skokowa)
class SecondHand extends ClockHand {
    @Override
    public void setTime(LocalTime time) {
        // 6 stopni na sekundę (360 / 60)
        this.angle = time.getSecond() * 6.0;
    }

    @Override
    public String toSvg() {
        return String.format("<line x1='100' y1='100' x2='100' y2='20' stroke='red' stroke-width='1.5' transform='rotate(%.1f 100 100)' />", angle);
    }
}

// Krok 10: Wskazówka minutowa (płynna z dokładnością do sekundy)
class MinuteHand extends ClockHand {
    @Override
    public void setTime(LocalTime time) {
        // 6 stopni na minutę + 0.1 stopnia na sekundę (6 / 60)
        this.angle = (time.getMinute() * 6.0) + (time.getSecond() * 0.1);
    }

    @Override
    public String toSvg() {
        return String.format("<line x1='100' y1='100' x2='100' y2='30' stroke='black' stroke-width='3' transform='rotate(%.1f 100 100)' />", angle);
    }
}

// Krok 10: Wskazówka godzinowa (płynna z dokładnością do sekundy)
class HourHand extends ClockHand {
    @Override
    public void setTime(LocalTime time) {
        // 30 stopni na godzinę (360 / 12) + 0.5 stopnia na minutę + odpowiednio za sekundy
        int hour12 = time.getHour() % 12;
        this.angle = (hour12 * 30.0) + (time.getMinute() * 0.5) + (time.getSecond() * (0.5 / 60.0));
    }

    @Override
    public String toSvg() {
        return String.format("<line x1='100' y1='100' x2='100' y2='45' stroke='black' stroke-width='5' transform='rotate(%.1f 100 100)' />", angle);
    }
}