import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

public class AnalogClock extends Clock {
    // Krok 11: Polimorficzna lista wskazówek
    private final List<ClockHand> hands;

    public AnalogClock(City city) {
        super(city);
        this.hands = Arrays.asList(new HourHand(), new MinuteHand(), new SecondHand());
        onTimeChanged(); // Synchronizacja startowa
    }

    // Krok 11: Aktualizacja bez nadpisywania metod setCurrentTime / setTime
    @Override
    protected void onTimeChanged() {
        if (hands != null && currentTime != null) {
            for (ClockHand hand : hands) {
                hand.setTime(this.currentTime);
            }
        }
    }

    // Krok 7 & 11: Generowanie kompletnego SVG
    public void toSvg(String filePath) throws IOException {
        StringBuilder svg = new StringBuilder();
        svg.append("<svg width='200' height='200' xmlns='http://www.w3.org/2000/svg'>\n");

        // Tarcza zegara (Krok 7)
        svg.append("  <circle cx='100' cy='100' r='95' stroke='black' stroke-width='3' fill='white' />\n");
        svg.append("  <circle cx='100' cy='100' r='4' fill='black' />\n");

        // Kreski godzinowe na tarczy
        for (int i = 0; i < 12; i++) {
            svg.append(String.format("  <line x1='100' y1='10' x2='100' y2='18' stroke='black' stroke-width='2' transform='rotate(%d 100 100)' />\n", i * 30));
        }

        // Renderowanie wskazówek (Krok 11)
        for (ClockHand hand : hands) {
            svg.append("  ").append(hand.toSvg()).append("\n");
        }

        svg.append("</svg>");

        try (FileWriter fw = new FileWriter(filePath)) {
            fw.write(svg.toString());
        }
    }

    // Krok 12: Statyczna metoda generująca strukturę katalogów i plików miast
    public static void generateAnalogClocksSvg(List<City> cities, AnalogClock clock) throws IOException {
        // Nazwa katalogu z funkcji toString() obiektu zegara (np. "14-35-00")
        String dirName = clock.toString().replace(":", "-");
        Files.createDirectories(Paths.get(dirName));

        for (City city : cities) {
            // Przestawiamy zegar na dane miasto
            clock.setCity(city);

            String fileName = dirName + File.separator + city.getName() + ".svg";
            clock.toSvg(fileName);
        }
    }
}