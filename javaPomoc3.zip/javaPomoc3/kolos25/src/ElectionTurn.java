import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ElectionTurn {
    private List<Candidate> candidateList;
    private List<Vote> votes = new ArrayList<>();

    public ElectionTurn(List<Candidate> candidateList) {
        this.candidateList = candidateList;
    }

    public void populate(String path) throws IOException {
        List<String> lines = Files.readAllLines(Path.of(path));

        // Sprawdzamy, czy plik nie jest pusty
        if (lines.isEmpty()) return;

        // Pętla startuje od i = 1 zamiast od 0, dzięki czemu całkowicie pomijamy pierwszy wiersz (nagłówek)
        for (int i = 1; i < lines.size(); i++) {
            String linia = lines.get(i);

            // Na wypadek, gdyby na końcu pliku była pusta linia, ignorujemy ją
            if (linia.trim().isEmpty()) {
                continue;
            }

            votes.add(Vote.fromCsvLine(linia, candidateList));
        }
    }
    // KROK 17: Wersja bezargumentowa - podsumowuje wszystkie głosy w turze
    public Vote summarize() {
        return Vote.summarize(this.votes, new ArrayList<>());
    }

    // KROK 17: Wersja z argumentem - filtruje głosy po lokalizacji, a potem podsumowuje
    public Vote summarize(List<String> locationPattern) {
        // 1. Filtrujemy listę głosów z tej tury na podstawie wzorca lokalizacji
        List<Vote> filteredVotes = Vote.filterByLocation(this.votes, locationPattern);

        // 2. Wywołujemy podsumowanie dla przefiltrowanej listy, przekazując tę samą lokalizację
        return Vote.summarize(filteredVotes, locationPattern);
    }

    public Candidate winner() throws NoWinnerException {
        //Vote summarized = Vote.summarize(this.votes, new ArrayList<>()); tak lub jak u dołu
        Vote summarized = this.summarize();
        for (Candidate candidate : candidateList) {
            if (summarized.percentage(candidate) > 50.0) {
                return candidate;
            }
        }
        throw new NoWinnerException("Brak zwycięzcy w tej turze.");
    }


    // KROK 14: Wyłonienie dwóch najlepszych kandydatów do dogrywki (II tury)
    public List<Candidate> runoffCandidates() {
        // 1. Agregujemy głosy ze wszystkich komisji/gmin dla tej tury
       // Vote summarized = Vote.summarize(this.votes, new ArrayList<>());
        Vote summarized = this.summarize();
        // 2. Tworzymy kopię listy kandydatów, aby nie zaburzyć oryginalnej kolejności w klasie
        List<Candidate> sortedCandidates = new ArrayList<>(this.candidateList);

        // 3. Sortujemy kandydatów malejąco (od największej liczby głosów do najmniejszej)
        // Porównujemy wynik c2 z c1 (odwrócona kolejność), co daje sortowanie malejące
        sortedCandidates.sort((c1, c2) -> Integer.compare(summarized.votes(c2), summarized.votes(c1)));

        // 4. Zwracamy dwóch pierwszych kandydatów z posortowanej listy
        // Math.min zabezpiecza nas przed błędem, gdyby kandydatów na liście było mniej niż dwóch
        return sortedCandidates.subList(0, Math.min(2, sortedCandidates.size()));
    }

}