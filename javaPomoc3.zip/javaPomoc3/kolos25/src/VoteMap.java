import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class VoteMap extends VoivodeshipMap {
    // Struktura przechowująca wyniki wyborów przekazane z kroku 19
    private Map<String, Map<String, Integer>> voteResults = new HashMap<>();
    
    // Mapowanie Kandydat -> Kolor weksylarny/polityczny
    private final Map<String, String> candidateColors = new HashMap<>();

    public VoteMap() {
        // Dowolne powiązanie kandydatów z wybranymi kolorami (przykład dla II tury)
        candidateColors.put("Kandydat A", "#1E3A8A"); // Ciemnoniebieski
        candidateColors.put("Kandydat B", "#DC2626"); // Czerwony
    }

    // Metoda pozwalająca zapisać uzyskane wcześniej wyniki głosowania
    public void setVoteResults(Map<String, Map<String, Integer>> results) {
        this.voteResults = results;
    }

    // Nadpisanie metody dobierającej kolor na podstawie zwycięzcy w danym województwie
    @Override
    protected String getColorForVoivodeship(String voivodeshipName) {
        Map<String, Integer> results = voteResults.get(voivodeshipName);
        
        // Jeśli brak danych dla województwa, zwracamy kolor neutralny
        if (results == null || results.isEmpty()) {
            return "#E5E7EB"; 
        }

        String winner = null;
        int maxVotes = -1;

        // Wyznaczenie kandydata z największą liczbą głosów
        for (Map.Entry<String, Integer> entry : results.entrySet()) {
            if (entry.getValue() > maxVotes) {
                maxVotes = entry.getValue();
                winner = entry.getKey();
            }
        }

        // Zwrócenie koloru przypisanego do zwycięzcy lub domyślnego w przypadku braku mapowania
        return candidateColors.getOrDefault(winner, "#9CA3AF");
    }

    public static void main(String[] args) {
        try {
            // 1. Pobranie danych strukturalnych z Kroku 19
            VoivodeshipMap baseMap = new VoivodeshipMap();
            ElectionTurn secondTurn = new ElectionTurn(2);
            
            Map<String, Map<String, Integer>> computedResults = new HashMap<>();
            for (String voivodeship : baseMap.getVoivodeshipNames()) {
                computedResults.put(voivodeship, secondTurn.summarize(voivodeship));
            }

            // 2. Inicjalizacja dedykowanej mapy wyborczej VoteMap
            VoteMap voteMap = new VoteMap();
            voteMap.setVoteResults(computedResults);

            // 3. Wygenerowanie wizualizacji SVG 
            // Każde województwo przyjmie barwę kandydata, który zdobył tam najwięcej głosów
            voteMap.saveToSvg("election_results_map.svg");
            System.out.println("Zapisano mapę wynikową wyborów do pliku election_results_map.svg");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
