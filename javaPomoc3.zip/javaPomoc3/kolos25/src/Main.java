import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        try {
            // Inicjalizacja i wczytanie danych z plików
            Election election = new Election();
            election.populate(); // wczyta kandydaci.txt oraz 1.csv dla firstTurn

            ElectionTurn firstTurn = election.getFirstTurn();

            System.out.println("--- TEST 1: Globalne podsumowanie pierwszej tury ---");
            Vote globalSummary = firstTurn.summarize(); // wersja bezargumentowa
            System.out.println(globalSummary);

            System.out.println("--- TEST 2: Podsumowanie tylko dla województwa lubelskiego ---");
            List<String> lubelskieFilter = List.of("lubelskie");
            Vote lubelskieSummary = firstTurn.summarize(lubelskieFilter); // wersja z argumentem
            System.out.println(lubelskieSummary);

            // Sprawdzenie zwycięzcy lub przejścia do dogrywki
            if (election.getWinner() != null) {
                System.out.println("Zwycięzca wyborów: " + election.getWinner().nazwaKandydata());
            } else {
                System.out.println("Brak zwycięzcy w 1. turze. Doszło do drugiej tury!");
                if (election.getSecondTurn() != null) {
                    System.out.println("--- TEST 3: Globalne podsumowanie drugiej tury ---");
                    Vote secondTurnSummary = election.getSecondTurn().summarize();
                    System.out.println(secondTurnSummary);
                    System.out.println("Ostateczny zwycięzca (II tura): " + election.getWinner().nazwaKandydata());
                }
            }

        } catch (IOException e) {
            System.err.println("Błąd podczas wczytywania plików: " + e.getMessage());
        }
    }
}