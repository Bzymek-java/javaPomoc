//Krok 1.
//Utwórz rekord Candidate zawierający nazwę kandydata.
public record Candidate(String nazwaKandydata) {

}
