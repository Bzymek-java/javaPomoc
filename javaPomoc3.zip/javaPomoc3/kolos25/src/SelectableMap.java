public class SelectableMap extends VoivodeshipMap {
    private String selectedVoivodeship = null;
    private final String highlightColor = "#FF5733"; // Wyróżniający kolor (np. pomarańczowo-czerwony)
    private final String defaultColor = "#E0E0E0";   // Standardowy kolor reszty województw

    // Publiczna metoda zaznaczania województwa
    public void select(String voivodeshipName) {
        if (voivodeshipPaths.containsKey(voivodeshipName)) {
            this.selectedVoivodeship = voivodeshipName;
        } else {
            System.out.println("Niepoprawna nazwa województwa: " + voivodeshipName);
        }
    }

    // Nadpisanie chronionej metody wyboru koloru
    @Override
    protected String getColorForVoivodeship(String voivodeshipName) {
        if (voivodeshipName.equals(selectedVoivodeship)) {
            return highlightColor;
        }
        return defaultColor;
    }

    public static void main(String[] args) {
        try {
            SelectableMap map = new SelectableMap();
            
            // Test działania metody select()
            map.select("mazowieckie");
            
            // Zapis do pliku SVG - mazowieckie będzie wyróżnione kolorem #FF5733
            map.saveToSvg("selectable_map.svg");
            System.out.println("Zapisano mapę z zaznaczonym województwem do selectable_map.svg");
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
