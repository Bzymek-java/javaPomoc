import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Vote {
    private Map<Candidate, Integer> votesForCandidate = new HashMap<>();
    private List<String> location;

    public static Vote fromCsvLine(String csvLine, List<Candidate> candidates) {
        Vote vote = new Vote();
        String[] data = csvLine.split(",");

        vote.location = new ArrayList<>();
        vote.location.add(data[2]); // województwo
        vote.location.add(data[1]); // powiat
        vote.location.add(data[0]); // gmina

        for (int i = 0; i < candidates.size(); i++) {
            int liczbaGlosow = Integer.parseInt(data[i + 3]);
            vote.votesForCandidate.put(candidates.get(i), liczbaGlosow);
        }
        return vote;
    }

    // KROK 8: Dodano modyfikator 'static'
    // KROK 17: Modyfikacja metody summarize o parametr lokalizacji
    public static Vote summarize(List<Vote> votes, List<String> location) {
        Vote summarizedVote = new Vote();

        // Ustawiamy przekazaną w argumencie lokalizację (zamiast pustej listy)
        summarizedVote.location = new ArrayList<>(location);
        summarizedVote.votesForCandidate = new HashMap<>();

        for (Vote vote : votes) {
            for (Map.Entry<Candidate, Integer> entry : vote.votesForCandidate.entrySet()) {
                Candidate candidate = entry.getKey();
                Integer liczbaGlosow = entry.getValue();

                summarizedVote.votesForCandidate.put(
                        candidate, summarizedVote.votesForCandidate.getOrDefault(candidate, 0) + liczbaGlosow
                );
            }
        }
        return summarizedVote;
    }

    public int votes(Candidate candidate) {
        return votesForCandidate.getOrDefault(candidate, 0);
    }

    // KROK 9: Poprawiono literówkę z 'precentage' na 'percentage'
    public double percentage(Candidate candidate) {
        int sumaGlosow = 0;
        for (Integer liczbaGlosow : votesForCandidate.values()) {
            sumaGlosow += liczbaGlosow;
        }
        if (sumaGlosow == 0) {
            return 0;
        }
        return (votes(candidate) * 100.0) / sumaGlosow;
    }

    // KROK 10 & 11: Suma wszystkich głosów liczona jest dokładnie RAZ przed pętlą wyświetlającą wyniki
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();

        int sumaGlosow = 0;
        for (Integer liczbaGlosow : votesForCandidate.values()) {
            sumaGlosow += liczbaGlosow;
        }

        for (Candidate candidate : votesForCandidate.keySet()) {
            int glosy = votes(candidate);
            double procent = 0;

            if (sumaGlosow != 0) {
                procent = (glosy * 100.0) / sumaGlosow;
            }

            builder.append(candidate.nazwaKandydata())
                    .append(" - ")
                    .append(String.format("%.2f", procent)) // ładne zaokrąglenie do 2 miejsc po przecinku
                    .append("%\n");
        }
        return builder.toString();
    }
    // KROK 16: Filtrowanie listy głosów na podstawie hierarchii lokalizacji
    public static List<Vote> filterByLocation(List<Vote> votes, List<String> locationDescription) {
        List<Vote> filteredVotes = new ArrayList<>();

        // Jeśli lista filtrów jest pusta, bezpiecznie zwracamy pustą listę wyników
        if (locationDescription == null || locationDescription.isEmpty()) {
            return filteredVotes;
        }

        for (Vote vote : votes) {
            boolean isMatch = true;

            // Sprawdzamy tylko tyle poziomów, ile podano w argumencie locationDescription
            for (int i = 0; i < locationDescription.size(); i++) {
                // Zabezpieczenie przed wyjściem poza rozmiar lokalizacji w obiekcie Vote
                if (i >= vote.location.size()) {
                    isMatch = false;
                    break;
                }

                String pattern = locationDescription.get(i);
                String actual = vote.location.get(i);

                // Porównujemy ignorując wielkość liter (wygodne przy wpisywaniu np. "lubelskie" vs "Lubelskie")
                if (!actual.equalsIgnoreCase(pattern)) {
                    isMatch = false;
                    break; // Przerwij pętlę dla tego obiektu przy pierwszym niedopasowaniu
                }
            }

            // Jeśli obiekt przeszedł pomyślnie wszystkie kroki filtrowania
            if (isMatch) {
                filteredVotes.add(vote);
            }
        }

        return filteredVotes;
    }
}
