import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Election {
    private List<Candidate> candidate = new ArrayList<>();

    public ElectionTurn firstTurn = new ElectionTurn(candidate);
    public ElectionTurn secondTurn = null; // Początkowo null, zostanie utworzony w Kroku 15

    private Candidate winner;

    public List<Candidate> getCandidate() {
        return new ArrayList<>(candidate);
    }

    public void populateCandidates(String path) throws IOException {
        List<String> lines = Files.readAllLines(Path.of(path));
        for (String linia : lines) {
            candidate.add(new Candidate(linia));
        }
    }

    // KROK 15: Rozbudowa metody populate() o obsługę drugiej tury
    public void populate() throws IOException {
        populateCandidates("kandydaci.txt");
        firstTurn.populate("1.csv");

        try {
            // Próba wyłonienia zwycięzcy w 1. turze
            this.winner = firstTurn.winner();
        } catch (NoWinnerException e) {
            // Głosowanie nie przyniosło rozstrzygnięcia -> czas na II turę!

            // 1. Uzyskanie listy dwóch kandydatów, którzy zakwalifikowali się do dogrywki
            List<Candidate> runoffCandidates = firstTurn.runoffCandidates();

            // 2. Utworzenie obiektu secondTurn z ograniczoną listą kandydatów
            this.secondTurn = new ElectionTurn(runoffCandidates);

            // 3. Wczytanie danych z pliku 2.csv i zapełnienie nimi obiektu secondTurn
            this.secondTurn.populate("2.csv");

            // 4. Odczytanie zwycięzcy drugiej tury i ustawienie go jako zwycięzcę całych wyborów
            try {
                this.winner = secondTurn.winner();
            } catch (NoWinnerException ex) {
                // W teorii w II turze (gdy jest tylko 2 kandydatów) ktoś musi zdobyć ponad 50% głosów ważnych,
                // chyba że nastąpiłby idealny remis. Obsługujemy wyjątek dla świętego spokoju kompilatora.
                System.out.println("Wyjątkowa sytuacja: Druga tura również nie wyłoniła zwycięzcy: " + ex.getMessage());
            }
        }
    }

    public Candidate getWinner() {
        return winner;
    }

    public ElectionTurn getFirstTurn() {
        return firstTurn;
    }

    public ElectionTurn getSecondTurn() {
        return secondTurn;
    }
}