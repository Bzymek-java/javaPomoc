public static void main(String[] args) throws IOException {
    Server server = new Server();
    server.listen();
}