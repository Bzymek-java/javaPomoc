import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.AbstractList;
import java.util.ArrayList;

public class Server {
    private ServerSocket serverSocket;
    private AbstractList<ClientHandler> handlers = new ArrayList<>();

    public Server() throws IOException {
        serverSocket = new ServerSocket(3000);
    }
    public void broadcast(String message){
        handlers.forEach(handler -> handler.send(message));
    }

    public void removeHandler(ClientHandler handler){
        handlers.remove(handler);
    }

    public void listen() throws IOException {
        System.out.println("Server started");
        while (true){
           Socket socket = serverSocket.accept();
           ClientHandler handler = new ClientHandler(socket,this);
           Thread thread = new Thread(handler);
           thread.start();
           handlers.add(handler);
        }
    }
    //zostało wyodrębnione do metody w klasie ClientHandler
    public void serverClient() throws IOException{
        Socket socket = serverSocket.accept();

        InputStream input = socket.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(input));
        OutputStream output = socket.getOutputStream();
        PrintWriter writer = new PrintWriter(output,true);

        String message;
        writer.println("Hello!");
        while ((message = reader.readLine()) != null){
            writer.println(message);
            System.out.println(message);
        }
        socket.close();
    }
}