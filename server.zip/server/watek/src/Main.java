public static void main(String[] args){
    Obliczenia obliczenia1 = new Obliczenia();
    Obliczenia obliczenia2 = new Obliczenia();

    Thread thread1= new Thread(obliczenia1);
    Thread thread2 = new Thread(obliczenia2);

    thread1.start();
    thread2.start();
}