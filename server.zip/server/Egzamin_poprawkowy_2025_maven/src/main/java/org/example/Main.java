package org.example;

public class Main {
    public static void main(String[] args)throws Exception{
        Scooter s1 = new Scooter(45,7);
        Scooter s2 = new Scooter(45,3);
        Scooter s3 = new Scooter(45,1);
        Scooter s4 = new Scooter(45,5);
        Bicycle b5 = new Bicycle(45);
        Station station1 = new Station("stacja", 4);

        station1.vehicles.add(s1);
        station1.vehicles.add(s2);
        station1.vehicles.add(s3);
        station1.vehicles.add(s4);
        station1.vehicles.add(b5);

        station1.dump();
    }
}
