package org.example;

public class Scooter extends Vehicle {
    private int battery;

    public Scooter(int battery, int id){
        this.battery = battery;
        super(id);
    }

    public int getBattery(){
        return battery;
    }

    @Override
    public String toString() {
        return "Scooter " + this.getId();
    }
}
