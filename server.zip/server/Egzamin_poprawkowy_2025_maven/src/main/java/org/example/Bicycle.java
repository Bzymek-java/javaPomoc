package org.example;

public class Bicycle extends Vehicle{
    public Bicycle(int id){
        super(id);
    }
}
