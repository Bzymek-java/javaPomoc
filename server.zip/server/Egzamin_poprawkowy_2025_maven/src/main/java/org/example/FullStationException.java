package org.example;

public class FullStationException extends RuntimeException {
    public FullStationException(String message){
        super(message);
    }
}
