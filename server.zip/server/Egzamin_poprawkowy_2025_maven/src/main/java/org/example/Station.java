package org.example;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Station {
    public String stationName;
    public int spaces;
    public List<Vehicle> vehicles;

    public Station(String stationName, int spaces){
        this.stationName = stationName;
        this.spaces = spaces;
        this.vehicles = new ArrayList<>(spaces);
    }


    public Vehicle rentVehicle(int id){
        for(Vehicle vehicle : vehicles){
            if(id == vehicle.getId()){
                vehicles.remove(vehicle);
                return vehicle;
            }
        }
        return null;
    }

    public void returnVehicle(Vehicle vehicle) throws FullStationException, IOException {
        if (vehicles.size() == spaces){
            throw new FullStationException("Stacja jest pełna");
        }
        vehicles.add(vehicle);
        dump();
    }
    public Bicycle rentBicycle() throws IOException {
       for(Vehicle vehicle : vehicles){
           if (vehicle instanceof Bicycle){
               vehicles.remove(vehicle);
               dump();
               return (Bicycle) vehicle;
           }
       }
       return null;
   }

    public Scooter rentScooter() {
        Scooter bestScooter = null;

        for (Vehicle vehicle : vehicles) {
            if (vehicle instanceof Scooter) {
                Scooter scooter = (Scooter) vehicle;

                if (bestScooter == null ||
                        scooter.getBattery() > bestScooter.getBattery()) {
                    bestScooter = scooter;
                }
            }
        }

        if (bestScooter != null) {
            vehicles.remove(bestScooter);
        }

        return bestScooter;
    }


    public void dump() throws IOException  {
        FileWriter writer = new FileWriter(stationName);
        writer.write("Station name= " + stationName + "\n");
        writer.write("Spaces= " + spaces + "\n");

        for(Vehicle vehicle : vehicles){
            if(vehicle instanceof Bicycle){
                writer.write("Bicycle= "+ vehicle.getId()+"\n");
            }else if(vehicle instanceof Scooter){
                Scooter scooter = (Scooter) vehicle;

                writer.write("Scooter= "+ vehicle.getId() + " Battery=" +scooter.getBattery() );
            }
        }
        writer.close();
    }

    public static Station load(String stationName) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new FileReader(stationName))) {

            String line = reader.readLine();
            String name = line.substring("StationName=".length());

            line = reader.readLine();
            int spaces = Integer.parseInt(
                    line.substring("Spaces=".length())
            );

            Station station = new Station(name, spaces);

            while ((line = reader.readLine()) != null) {

                if (line.startsWith("Bicycle=")) {
                    int id = Integer.parseInt(
                            line.substring("Bicycle=".length())
                    );

                    station.vehicles.add(new Bicycle(id));

                } else if (line.startsWith("Scooter=")) {

                    String[] data = line.substring("Scooter=".length())
                            .split(";");

                    int battery = Integer.parseInt(data[0]);
                    int id = Integer.parseInt(data[1]);

                    station.vehicles.add(
                            new Scooter(battery, id)
                    );
                }
            }

            return station;
        }
    }
}
