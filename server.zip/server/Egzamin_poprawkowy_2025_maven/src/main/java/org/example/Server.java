package org.example;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static void main(String[] args) {

        if (args.length == 0) {
            System.out.println("Podaj nazwę pliku stacji.");
            return;
        }

        try {
            Station station = Station.load(args[0]);

            ServerSocket serverSocket = new ServerSocket(12345);

            System.out.println("Serwer uruchomiony.");
            System.out.println("Oczekiwanie na klientów...");

            while (true) {

                Socket clientSocket = serverSocket.accept();

                System.out.println("Połączono z klientem.");

                BufferedReader input = new BufferedReader(
                        new InputStreamReader(
                                clientSocket.getInputStream()
                        )
                );

                PrintWriter output = new PrintWriter(
                        clientSocket.getOutputStream(),
                        true
                );

                String command = input.readLine();

                String response = handleCommand(command, station);

                output.println(response);

                clientSocket.close();

                System.out.println("Klient rozłączony.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String handleCommand(String command, Station station) {

        if (command == null || command.isBlank()) {
            return "ERROR Empty command";
        }

        String[] parts = command.split(" ");

        try {

            // RENT VEHICLE <id>
            if (parts[0].equals("RENT")
                    && parts.length == 3
                    && parts[1].equals("VEHICLE")) {

                int id = Integer.parseInt(parts[2]);

                Vehicle vehicle = station.rentVehicle(id);

                if (vehicle == null) {
                    return "ERROR Vehicle not found";
                }

                return "OK Vehicle " + vehicle.getId() + " rented";
            }

            // RENT BICYCLE
            if (parts[0].equals("RENT")
                    && parts.length == 2
                    && parts[1].equals("BICYCLE")) {

                Bicycle bicycle = station.rentBicycle();

                if (bicycle == null) {
                    return "ERROR No bicycle available";
                }

                return "OK Bicycle " + bicycle.getId() + " rented";
            }

            // RENT SCOOTER
            if (parts[0].equals("RENT")
                    && parts.length == 2
                    && parts[1].equals("SCOOTER")) {

                Scooter scooter = station.rentScooter();

                if (scooter == null) {
                    return "ERROR No scooter available";
                }

                return "OK Scooter " + scooter.getId()
                        + " battery=" + scooter.getBattery()
                        + " rented";
            }

            // RETURN BICYCLE <id>
            if (parts[0].equals("RETURN")
                    && parts.length == 3
                    && parts[1].equals("BICYCLE")) {

                int id = Integer.parseInt(parts[2]);

                Bicycle bicycle = new Bicycle(id);

                station.returnVehicle(bicycle);

                return "OK Bicycle returned";
            }

            // RETURN SCOOTER <battery> <id>
            if (parts[0].equals("RETURN")
                    && parts.length == 4
                    && parts[1].equals("SCOOTER")) {

                int battery = Integer.parseInt(parts[2]);
                int id = Integer.parseInt(parts[3]);

                Scooter scooter = new Scooter(battery, id);

                station.returnVehicle(scooter);

                return "OK Scooter returned";
            }

            return "ERROR Unknown command";

        } catch (NumberFormatException e) {
            return "ERROR Invalid number";

        } catch (FullStationException e) {
            return "ERROR Station is full";

        } catch (Exception e) {
            return "ERROR " + e.getMessage();
        }
    }
}