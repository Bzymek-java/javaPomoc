import org.example.Bicycle;
import org.example.Scooter;
import org.example.Station;
import org.example.Vehicle;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class Test {

    @org.junit.jupiter.api.Test
    void onlyOneScooter() throws IOException {
        Station station = new Station("Stacja",5);
        Scooter scooter = new Scooter(5,1);
        station.vehicles.add(scooter);

        Scooter result = station.rentScooter();

        assertNotNull(result);
        assertEquals(scooter,result);
        assertEquals(0,station.vehicles.size());
    }

    @org.junit.jupiter.api.Test
    void moreThenOneScooter() throws IOException {
        Station station = new Station("Stacja",5);
        Scooter scooter = new Scooter(5,1);
        Scooter scooter1 = new Scooter(67,2);
        station.vehicles.add(scooter);
        station.vehicles.add(scooter1);

        Scooter result = station.rentScooter();

        assertNotNull(result);
        assertEquals(1,station.vehicles.size());
    }

    @org.junit.jupiter.api.Test
    void noScooter() throws IOException {
        Station station = new Station("Stacja",5);
        station.vehicles.add(new Bicycle(4));
        station.vehicles.add(new Bicycle(2));

        Scooter result = station.rentScooter();

        assertNull(result);
        assertEquals(2,station.vehicles.size());
    }
}
