import game.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DuelEvaluateTest {

    @Test
    void shouldReturnCorrectResultWhenPlayer1Wins() {
        // Given
        Player p1 = new Player();
        Player p2 = new Player();
        Duel duel = new Duel(p1, p2);

        // When
        p1.makeGesture(Gesture.PAPER);    // Papier
        p2.makeGesture(Gesture.ROCK);     // Kamień

        Duel.Result result = duel.evaluate();

        // Then
        assertNotNull(result, "Wynik nie powinien być null przy wygranej");
        assertEquals(p1, result.winner(), "Gracz 1 powinien być zwycięzcą (Papier vs Kamień)");
        assertEquals(p2, result.loser(), "Gracz 2 powinien być przegranym");
    }

    @Test
    void shouldReturnNullWhenThereIsADraw() {
        // Given
        Player p1 = new Player();
        Player p2 = new Player();
        Duel duel = new Duel(p1, p2);

        // When
        p1.makeGesture(Gesture.SCISSORS); // Nożyce
        p2.makeGesture(Gesture.SCISSORS); // Nożyce

        Duel.Result result = duel.evaluate();

        // Then
        assertNull(result, "Metoda evaluate() powinna zwrócić null w przypadku remisu");
    }
}