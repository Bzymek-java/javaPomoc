package game;

public class Duel {
    private final Player player1;
    private final Player player2;
    private Gesture gesture1;
    private Gesture gesture2;

    // Krok 5: Prywatne pole na interfejs funkcyjny i mutator
    private Runnable onEnd;

    public void setOnEnd(Runnable onEnd) {
        this.onEnd = onEnd;
    }

    public Duel(Player player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
        this.player1.enterDuel(this);
        this.player2.enterDuel(this);
    }

    public void handleGesture(Player player, Gesture gesture) {
        if (player == player1) {
            this.gesture1 = gesture;
        } else if (player == player2) {
            this.gesture2 = gesture;
        }

        // Krok 5: Sprawdzenie czy obaj gracze wykonali ruch i wywołanie callbacku
        if (gesture1 != null && gesture2 != null && onEnd != null) {
            onEnd.run();
        }
    }

    public Result evaluate() {
        if (gesture1 == null || gesture2 == null) {
            return null;
        }

        int comparison = gesture1.compareWith(gesture2);

        if (comparison > 0) {
            player1.leaveDuel();
            player2.leaveDuel();
            return new Result(player1, player2);
        } else if (comparison < 0) {
            player1.leaveDuel();
            player2.leaveDuel();
            return new Result(player2, player1);
        } else {
            // Przy remisie czyścimy gesty, aby gracze mogli rzucić je ponownie w tym samym pojedynku
            this.gesture1 = null;
            this.gesture2 = null;
            return null;
        }
    }

    public record Result(Player winner, Player loser) {}
}