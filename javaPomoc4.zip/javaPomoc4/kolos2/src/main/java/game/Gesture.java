package game;

public enum Gesture {
    ROCK,
    PAPER,
    SCISSORS;

    /**
     * Przekształca ciąg znaków na odpowiedni obiekt typu Gesture.
     * * @param text skrót gestu ("r", "p" lub "s")
     * @return odpowiedni obiekt Gesture lub null, jeśli tekst nie pasuje
     */
    public static Gesture fromString(String text) {
        if (text == null) {
            return null;
        }

        switch (text.toLowerCase().trim()) {
            case "r":
                return ROCK;
            case "p":
                return PAPER;
            case "s":
                return SCISSORS;
            default:
                return null; // Można też rzucić wyjątkiem IllegalArgumentException
        }
    }
    public int compareWith(Gesture other) {
        // Jeśli gesty są takie same, mamy remis
        if (this == other) {
            return 0;
        }

        // Definiujemy przypadki, w których 'this' (obecny obiekt) wygrywa
        switch (this) {
            case ROCK:
                return (other == SCISSORS) ? 1 : -1;
            case PAPER:
                return (other == ROCK) ? 1 : -1;
            case SCISSORS:
                return (other == PAPER) ? 1 : -1;
            default:
                throw new IllegalStateException("Nieznany gest: " + this);
        }
    }
}