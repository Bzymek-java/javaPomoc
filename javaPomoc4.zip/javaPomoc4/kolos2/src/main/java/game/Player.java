package game;

public class Player {
    // Prywatne pole zgodnie ze schematem UML
    private Duel duel;

    // Do klasy Player nie dopisujemy konstruktora ani dodatkowych pól/metod.

    public void makeGesture(Gesture gesture) {
        if (duel != null) {
            duel.handleGesture(this, gesture);
        }
    }

    public void enterDuel(Duel duel) {
        this.duel = duel;
    }

    public void leaveDuel() {
        this.duel = null;
    }

    public boolean isDuelling() {
        return this.duel != null;
    }
}