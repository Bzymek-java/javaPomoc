package server;

import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class Database {
    // Ścieżka do pliku bazy danych SQLite
    private static final String DB_URL = "jdbc:sqlite:database.db";

    public Database() {
        // Opcjonalnie: można tu upewnić się, czy sterownik SQLite jest załadowany
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("Brak sterownika SQLite JDBC: " + e.getMessage());
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    // Krok 1: Sprawdzenie loginu i hasła w bazie
    public boolean authenticate(String login, String password) {
        String sql = "SELECT * FROM users WHERE login = ? AND password = ?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, login);
            pstmt.setString(2, password);

            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next(); // Zwraca true, jeśli znaleziono pasujący wiersz
            }
        } catch (SQLException e) {
            System.err.println("Błąd autentykacji (DB): " + e.getMessage());
            return false;
        }
    }

    // Krok 2: Aktualizacja punktacji po grze
    public void updateLeaderboard(String winner, String loser) {
        String sqlWinner = "UPDATE users SET points = points + 1 WHERE login = ?";
        String sqlLoser = "UPDATE users SET points = points - 1 WHERE login = ?";

        try (Connection conn = getConnection()) {
            // Wyłączamy auto-commit, aby obie operacje wykonały się jako jedna transakcja
            conn.setAutoCommit(false);

            try (PreparedStatement pstmtWin = conn.prepareStatement(sqlWinner);
                 PreparedStatement pstmtLose = conn.prepareStatement(sqlLoser)) {

                pstmtWin.setString(1, winner);
                pstmtWin.executeUpdate();

                pstmtLose.setString(1, loser);
                pstmtLose.executeUpdate();

                conn.commit(); // Zatwierdzenie zmian
                System.out.println("Zaktualizowano ranking w bazie dla: " + winner + " oraz " + loser);
            } catch (SQLException e) {
                conn.rollback(); // Wycofanie zmian w razie błędu
                throw e;
            }
        } catch (SQLException e) {
            System.err.println("Błąd aktualizacji rankingu (DB): " + e.getMessage());
        }
    }

    // Krok 3: Pobranie posortowanego rankingu
    public Map<String, Integer> getLeaderboard() {
        String sql = "SELECT login, points FROM users ORDER BY points DESC";
        // LinkedHashMap gwarantuje zachowanie kolejności wstawiania (czyli kolejności z ORDER BY)
        Map<String, Integer> leaderboard = new LinkedHashMap<>();

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                leaderboard.put(rs.getString("login"), rs.getInt("points"));
            }
        } catch (SQLException e) {
            System.err.println("Błąd pobierania rankingu (DB): " + e.getMessage());
        }
        return leaderboard;
    }
}