package server;

import game.Gesture;
import game.Player;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

// Krok 1: ClientHandler dziedziczy po Player
public class ClientHandler extends Player implements Runnable {
    private final Socket socket;
    private final Server server;
    private PrintWriter out;
    private String login;
    private Thread thread;

    public ClientHandler(Socket socket, Server server) {
        this.socket = socket;
        this.server = server;
    }

    public void start() {
        this.thread = new Thread(this);
        this.thread.start();
    }

    public String getLogin() {
        return login;
    }

    public void sendMessage(String message) {
        if (out != null) {
            out.println(message);
        }
    }

    @Override
    public void run() {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)
        ) {
            this.out = writer;

            // Uproszczony proces logowania z kroku 5 (zakładamy poprawne logowanie dla czytelności kodu)
            out.println("Podaj login:");
            this.login = in.readLine();
            out.println("Zalogowano pomyślnie jako: " + this.login);

            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                inputLine = inputLine.trim().toLowerCase();

                // Krok 4: Obsługa wiadomości w trakcie pojedynku
                if (isDuelling()) {
                    Gesture gesture = Gesture.fromString(inputLine);
                    if (gesture != null) {
                        // Wywołanie odziedziczonej metody z klasy Player
                        makeGesture(gesture);
                    } else {
                        sendMessage("Niepoprawny ruch. Wybierz p, r lub s.");
                    }
                } else {
                    // Krok 1: Wiadomość poza pojedynkiem traktowana jest jako login wyzwanego
                    server.challengeToDuel(this, inputLine);
                }
            }

        } catch (IOException e) {
            System.out.println("Rozłączono: " + login);
        } finally {
            server.removeClient(this);
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}