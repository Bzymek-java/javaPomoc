package server;

import game.Duel;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Server {
    private ServerSocket serverSocket;
    private final List<ClientHandler> clients = new ArrayList<>();
    private final Database database = new Database();

    public Server(int port) {
        try {
            serverSocket = new ServerSocket(port);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Database getDatabase() {
        return database;
    }

    // Krok 1 & 2 & 7: Logika rzucania wyzwania
    public synchronized void challengeToDuel(ClientHandler challenger, String challengeeLogin) {
        // Krok 7: Nie można wyzwać samego siebie
        if (challenger.getLogin().equalsIgnoreCase(challengeeLogin)) {
            challenger.sendMessage("Nie możesz wyzwać samego siebie!");
            return;
        }

        ClientHandler challengee = null;
        for (ClientHandler client : clients) {
            if (client.getLogin() != null && client.getLogin().equalsIgnoreCase(challengeeLogin)) {
                challengee = client;
                break;
            }
        }

        // Krok 2: Brak użytkownika o takim loginie
        if (challengee == null) {
            challenger.sendMessage("Nie znaleziono gracza o loginie: " + challengeeLogin);
            return;
        }

        // Krok 7: Gracz jest już w trakcie innego pojedynku
        if (challengee.isDuelling()) {
            challenger.sendMessage("Gracz " + challengeeLogin + " aktualnie prowadzi inny pojedynek!");
            return;
        }

        // Sukces - uruchamiamy pojedynek
        startDuel(challenger, challengee);
    }

//    // Krok 1 & 3 & 6: Logika rozpoczynania pojedynku i ustawiania onEnd
//    private void startDuel(ClientHandler challenger, ClientHandler challengee) {
//        // Krok 3: Tworzenie obiektu gry
//        Duel duel = new Duel(challenger, challengee);
//
//        // Krok 3: Powiadomienie graczy
//        challenger.sendMessage("Pojedynek rozpoczęty! Twój przeciwnik to " + challengee.getLogin() + ". Wybierz p, r lub s:");
//        challengee.sendMessage("Zostałeś wyzwany! Twój przeciwnik to " + challenger.getLogin() + ". Wybierz p, r lub s:");
//
//        // Krok 6: Definiowanie zachowania po zebraniu obu gestów
//        duel.setOnEnd(() -> {
//            Duel.Result result = duel.evaluate();
//
//            if (result == null) {
//                // Remis - gra toczy się dalej (w klasie Duel zresetowaliśmy gesty)
//                challenger.sendMessage("Remis! Wybierzcie gesty ponownie (p, r, s):");
//                challengee.sendMessage("Remis! Wybierzcie gesty ponownie (p, r, s):");
//            } else {
//                // Ktoś wygrał - rzutujemy obiekty Player z powrotem na ClientHandler, by wysłać im wiadomości
//                ClientHandler winner = (ClientHandler) result.winner();
//                ClientHandler loser = (ClientHandler) result.loser();
//
//                winner.sendMessage("Wygrałeś pojedynek z " + loser.getLogin() + "!");
//                loser.sendMessage("Przegrałeś pojedynek z " + winner.getLogin() + "!");
//
//                // Tutaj w przyszłości można wywołać database.updateLeaderboard(...)
//            }
//        });
//    }

    public synchronized void removeClient(ClientHandler client) {
        clients.remove(client);
    }

    public void listen() {
        System.out.println("Serwer czeka na połączenia...");
        while (true) {
            try {
                Socket socket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(socket, this);
                synchronized (this) {
                    clients.add(handler);
                }
                handler.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private void startDuel(ClientHandler challenger, ClientHandler challengee) {
        Duel duel = new Duel(challenger, challengee);

        challenger.sendMessage("Pojedynek rozpoczęty! Twój przeciwnik to " + challengee.getLogin() + ". Wybierz p, r lub s:");
        challengee.sendMessage("Zostałeś wyzwany! Twój przeciwnik to " + challenger.getLogin() + ". Wybierz p, r lub s:");

        duel.setOnEnd(() -> {
            Duel.Result result = duel.evaluate();

            if (result == null) {
                challenger.sendMessage("Remis! Wybierzcie gesty ponownie (p, r, s):");
                challengee.sendMessage("Remis! Wybierzcie gesty ponownie (p, r, s):");
            } else {
                ClientHandler winner = (ClientHandler) result.winner();
                ClientHandler loser = (ClientHandler) result.loser();

                winner.sendMessage("Wygrałeś pojedynek z " + loser.getLogin() + "!");
                loser.sendMessage("Przegrałeś pojedynek z " + winner.getLogin() + "!");

                // === KROK 2: Aktualizacja bazy danych po grze nieremisowej ===
                database.updateLeaderboard(winner.getLogin(), loser.getLogin());

                // === KROK 3: Wyświetlenie aktualnego rankingu na konsoli serwera ===
                printLeaderboardOnServerConsole();
            }
        });
    }

    // Krok 3: Pomocnicza metoda wypisująca ranking na serwerze
    private void printLeaderboardOnServerConsole() {
        System.out.println("\n========== AKTUALNY RANKING ==========");
        Map<String, Integer> leaderboard = database.getLeaderboard();

        int position = 1;
        for (Map.Entry<String, Integer> entry : leaderboard.entrySet()) {
            System.out.printf("%d. %-15s : %d pkt%n", position++, entry.getKey(), entry.getValue());
        }
        System.out.println("======================================\n");
    }

    public static void main(String[] args) {
        new Server(1234).listen();
    }
}